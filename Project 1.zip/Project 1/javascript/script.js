document.write("Hello World")
alert("Hey Lurde")
console.log("Hello World")